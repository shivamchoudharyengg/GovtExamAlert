<?php
// Start the session
session_start();

// Store the session ID for logging purposes (optional but recommended)
$sessionId = session_id();

// Capture user information if available (optional)
$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'Guest'; //Example, adjust to your user system.

// Destroy all session variables
session_unset();

// Destroy the session
session_destroy();

// Delete the session cookie if it exists
if (isset($_COOKIE[session_name()])) {
    //Use secure and httponly flags.
    setcookie(session_name(), '', time() - 3600, '/', '', true, true);
}

// Clear authentication tokens (if using remember me or similar)
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/', '', true, true);
}
// Clear other auth cookies if any.
//Example:
if (isset($_COOKIE['auth_token'])) {
    setcookie('auth_token', '', time() - 3600, '/', '', true, true);
}

// Log the logout action (important for security and auditing)
$logMessage = date('Y-m-d H:i:s') . " - User (ID: " . $userId . ") with Session ID: " . $sessionId . " logged out.\n";
error_log($logMessage, 3, 'logout.log'); // Log to a file

// Regenerate session ID (mitigate session fixation, though session_destroy() already does this)
session_regenerate_id(true);

// Prevent caching of the logout page
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Redirect to the homepage or login page
header("Location: index.php");
exit();
?>