-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2025 at 05:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `govt_exams`
--

-- --------------------------------------------------------

--
-- Table structure for table `government_exams`
--

CREATE TABLE `government_exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `minimum_percentage` varchar(100) DEFAULT NULL,
  `age_limit` varchar(100) DEFAULT NULL,
  `academic_qualification` text DEFAULT NULL,
  `official_website` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `government_exams`
--

INSERT INTO `government_exams` (`id`, `exam_name`, `minimum_percentage`, `age_limit`, `academic_qualification`, `official_website`, `created_at`, `updated_at`) VALUES
(1, 'UPSC Civil Services (IAS, IPS, IFS)', 'No minimum percentage', '21-32 years', 'Bachelor\'s degree in any discipline', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(2, 'UPSC Engineering Services', 'No minimum percentage', '21-30 years', 'Engineering degree in relevant discipline', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(3, 'UPSC Combined Medical Services', 'No minimum percentage', '32 years', 'MBBS', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(4, 'UPSC NDA (National Defence Academy)', 'No minimum percentage', '16.5-19.5 years', '12th pass (for Army/Navy), 12th with Physics & Mathematics (for Air Force)', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(5, 'UPSC CDS (Combined Defence Services)', 'No minimum percentage', '19-24 years', 'Bachelor\'s degree for OTA, 12th for Naval Academy', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(6, 'UPSC CAPF (Central Armed Police Forces)', 'No minimum percentage', '20-25 years', 'Bachelor\'s degree in any discipline', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(7, 'UPSC SCRA (Special Class Railway Apprentice)', 'No minimum percentage', '17-21 years', '12th with Physics, Chemistry, Mathematics', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(8, 'SSC CGL (Combined Graduate Level)', 'No minimum percentage', '18-32 years', 'Bachelor\'s degree in any discipline', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(9, 'SSC CHSL (Combined Higher Secondary Level)', 'No minimum percentage', '18-27 years', '12th pass', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(10, 'SSC Stenographer', 'No minimum percentage', '18-27 years', '12th pass', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(11, 'SSC JE (Junior Engineer)', 'No minimum percentage', '18-32 years', 'Diploma/Degree in relevant engineering field', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(12, 'SSC MTS (Multi-Tasking Staff)', 'No minimum percentage', '18-25 years', '10th pass', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(13, 'SSC CPO (Central Police Organization)', 'No minimum percentage', '20-25 years', 'Bachelor\'s degree in any discipline', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(14, 'SSC GD (General Duty) Constable', 'No minimum percentage', '18-23 years', '10th pass', 'https://ssc.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(15, 'IBPS PO (Probationary Officer)', '60% (may vary)', '20-30 years', 'Bachelor\'s degree in any discipline', 'https://www.ibps.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(16, 'IBPS Clerk', 'No minimum percentage', '20-28 years', 'Bachelor\'s degree in any discipline', 'https://www.ibps.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(17, 'IBPS RRB (Regional Rural Bank) Officer', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree in any discipline', 'https://www.ibps.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(18, 'IBPS RRB Clerk', 'No minimum percentage', '18-28 years', 'Bachelor\'s degree in any discipline', 'https://www.ibps.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(19, 'IBPS SO (Specialist Officer)', 'No minimum percentage', '20-30 years', 'Relevant professional qualification (CA/CS/MBA/Law/Engineering)', 'https://www.ibps.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(20, 'SBI PO (Probationary Officer)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree in any discipline', 'https://sbi.co.in/careers', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(21, 'SBI Clerk', 'No minimum percentage', '20-28 years', 'Bachelor\'s degree in any discipline', 'https://sbi.co.in/careers', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(22, 'SBI SO (Specialist Officer)', 'No minimum percentage', '21-30 years', 'Relevant professional qualification', 'https://sbi.co.in/careers', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(23, 'RBI Grade A Officer', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree with 60% marks', 'https://www.rbi.org.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(24, 'RBI Grade B Officer', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree with 60% marks (55% for SC/ST/PwD)', 'https://www.rbi.org.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(25, 'RBI Assistant', 'No minimum percentage', '20-28 years', 'Bachelor\'s degree in any discipline', 'https://www.rbi.org.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(26, 'NABARD Grade A & B', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree with 60% marks', 'https://www.nabard.org', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(27, 'SEBI Grade A Officer', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree with 60% marks', 'https://www.sebi.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(28, 'SIDBI Grade A Officer', 'No minimum percentage', '21-28 years', 'Bachelor\'s degree with 60% marks', 'https://www.sidbi.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(29, 'RRB NTPC (Non-Technical Popular Categories)', 'No minimum percentage', '18-33 years', 'Bachelor\'s degree/12th pass (varies by post)', 'https://indianrailways.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(30, 'RRB ALP (Assistant Loco Pilot)', 'No minimum percentage', '18-30 years', '10th pass + ITI/Diploma in relevant trade', 'https://indianrailways.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(31, 'RRB Group D', 'No minimum percentage', '18-33 years', '10th pass', 'https://indianrailways.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(32, 'RRB JE (Junior Engineer)', 'No minimum percentage', '18-33 years', 'Diploma/Degree in relevant engineering field', 'https://indianrailways.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(33, 'GATE (Graduate Aptitude Test in Engineering)', 'No minimum percentage', 'No age limit', 'Bachelor\'s degree in Engineering/Technology/Architecture/Science', 'https://gate.iitk.ac.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(34, 'UGC NET (National Eligibility Test)', '55% in Master\'s degree (50% for reserved categories)', 'No age limit', 'Master\'s degree in relevant subject', 'https://ugcnet.nta.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(35, 'CSIR UGC NET', '55% in Master\'s degree (50% for reserved categories)', 'No age limit', 'Master\'s degree in Science/Engineering', 'https://csirnet.nta.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(36, 'JEST (Joint Entrance Screening Test)', 'No minimum percentage', 'No age limit', 'Master\'s degree in Science', 'https://www.jest.org.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(37, 'AFCAT (Air Force Common Admission Test)', '60% marks in graduation', '20-24 years', 'Bachelor\'s degree in any discipline', 'https://afcat.cdac.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(38, 'INET (Indian Navy Entrance Test)', '60% in graduation', '19-24 years', 'Bachelor\'s degree (varies by branch)', 'https://www.joinindiannavy.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(39, 'CAT (Common Admission Test) for IIMs', 'No minimum percentage', 'No age limit', 'Bachelor\'s degree with 50% marks', 'https://iimcat.ac.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(40, 'CTET (Central Teacher Eligibility Test)', 'No minimum percentage', 'No age limit', 'Varies by level (Primary/Elementary)', 'https://ctet.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(41, 'NEET (National Eligibility cum Entrance Test)', '50% in 12th', '17+ years', '12th with Physics, Chemistry, Biology', 'https://neet.nta.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(42, 'JEE Main (Joint Entrance Examination)', 'No minimum percentage', 'No specific age limit', '12th with Physics, Chemistry, Mathematics', 'https://jeemain.nta.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(43, 'JEE Advanced', 'Top 2.5 lakh ranks in JEE Main', 'No specific age limit', '12th with Physics, Chemistry, Mathematics', 'https://jeeadv.ac.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(44, 'NTA CUET (Common University Entrance Test)', 'No minimum percentage', 'No age limit', '12th pass', 'https://cuet.nta.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(45, 'NVS (Navodaya Vidyalaya Samiti)', 'No minimum percentage', '18-35 years', 'Bachelor\'s degree (varies by post)', 'https://www.navodaya.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(46, 'KVS (Kendriya Vidyalaya Sangathan)', 'No minimum percentage', '18-35 years', 'Bachelor\'s degree (varies by post)', 'https://kvsangathan.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(47, 'Income Tax Inspector', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree in any discipline', 'https://incometaxindia.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(48, 'Customs & Central Excise Inspector', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree in any discipline', 'https://cbic.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(49, 'LIC AAO (Assistant Administrative Officer)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree with 60% marks', 'https://licindia.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(50, 'LIC ADO (Apprentice Development Officer)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree in any discipline', 'https://licindia.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(51, 'ESIC (Employees\' State Insurance Corporation)', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree (varies by post)', 'https://www.esic.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(52, 'EPFO (Employees\' Provident Fund Organisation)', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree in any discipline', 'https://www.epfindia.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(53, 'FCI (Food Corporation of India)', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree (varies by post)', 'https://fci.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(54, 'CWC (Central Warehousing Corporation)', 'No minimum percentage', '18-30 years', 'Bachelor\'s degree (varies by post)', 'https://cewacor.nic.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(55, 'Defense Research & Development Organization (DRDO)', 'No minimum percentage', '18-28 years', 'Bachelor\'s degree in relevant discipline', 'https://www.drdo.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(56, 'ISRO (Indian Space Research Organisation)', '65% in engineering', '18-35 years', 'Bachelor\'s/Master\'s in Engineering', 'https://www.isro.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(57, 'Indian Coast Guard', 'No minimum percentage', '18-26 years', 'Bachelor\'s degree', 'https://joinindiancoastguard.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(58, 'IB ACIO (Intelligence Bureau - Assistant Central Intelligence Officer)', 'No minimum percentage', '18-27 years', 'Bachelor\'s degree in any discipline', 'https://mha.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(59, 'NDA (National Dairy Development Board)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree (varies by post)', 'https://www.nddb.coop', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(60, 'BIS (Bureau of Indian Standards)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree in relevant discipline', 'https://www.bis.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(61, 'Indian Economic Service', 'No minimum percentage', '21-30 years', 'Master\'s degree in Economics/Statistics', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(62, 'Indian Statistical Service', 'No minimum percentage', '21-30 years', 'Master\'s degree in Statistics/Mathematics', 'https://www.upsc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(63, 'India Post (Postal Assistant/Sorting Assistant)', 'No minimum percentage', '18-27 years', '12th pass', 'https://www.indiapost.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(64, 'NHAI (National Highways Authority of India)', 'No minimum percentage', '21-30 years', 'Bachelor\'s degree in Civil Engineering', 'https://nhai.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(65, 'NHPC (National Hydroelectric Power Corporation)', 'No minimum percentage', '18-30 years', 'Engineering degree in relevant discipline', 'https://www.nhpcindia.com', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(66, 'ONGC (Oil and Natural Gas Corporation)', '60% in engineering', '18-30 years', 'Engineering degree in relevant discipline', 'https://www.ongcindia.com', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(67, 'BSNL JTO (Junior Telecom Officer)', 'No minimum percentage', '18-30 years', 'Engineering degree in relevant discipline', 'https://www.bsnl.co.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(68, 'SAIL (Steel Authority of India Limited)', 'No minimum percentage', '18-30 years', 'Engineering degree (varies by post)', 'https://www.sail.co.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13'),
(69, 'BARC (Bhabha Atomic Research Centre)', '60% in graduation', '18-26 years', 'Engineering degree/MSc in relevant discipline', 'https://www.barc.gov.in', '2025-03-09 17:02:13', '2025-03-09 17:02:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `qualification`, `created_at`) VALUES
(1, 'pratap', '123456@gmail.com', '$2y$10$dv1XsIXIBJ3nKl3dR3DL9eQvG4DT3T7qw10pmU8/liYdD03pUAzx2', '12th', '2025-01-30 07:59:34'),
(2, 'yoda', 'hello@gmail.com', '$2y$10$UadYKP7g4M6.XJpCbbL/MO.pFPpjwMoqGMoGO7Ei.0Vd12i9hcSOu', 'Bachelor\'s Degree', '2025-02-26 14:30:52'),
(3, 'abc', 'abc@gmail.com', '$2y$10$w0tROx1X3w/p4v1eWs2mleO/h5BbtaHloEGtzQbMcWa4dgqZudYy.', 'Bachelor\'s Degree', '2025-02-27 04:19:24'),
(4, 'pratap', '5858@gmail.com', '$2y$10$W2E9UvLWPd1TKcFOgbT36usaLeZttnSf8lsbcHTKapktCBtWnWfgS', 'Bachelor\'s Degree', '2025-03-09 17:32:04'),
(5, 'pratap', 'godarshourya@gmail.com', '$2y$10$9tmbSlIE.Em83wMNrk09ReyijLISagQuK3.FCm7gd.RsX97IZkrDu', 'Bachelor\'s Degree', '2025-03-09 17:36:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `government_exams`
--
ALTER TABLE `government_exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `government_exams`
--
ALTER TABLE `government_exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
