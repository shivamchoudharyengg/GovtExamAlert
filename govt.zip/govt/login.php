<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$database = "govt_exams";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    $sql = "SELECT id, name, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $name, $hashed_password);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION["user_id"] = $id;
            $_SESSION["user_name"] = $name;
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "No account found!";
    }
    $stmt->close();
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Exam alert</title>
    <link href="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.css" rel="stylesheet">
    <script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1a237e;
            --accent-orange: #ff6f00;
            --dark-bg: #0a192f;
            --card-bg: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(45deg, var(--dark-bg), #16213e);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Floating Elements */
        .floating-icons {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
            top: 0;
            left: 0;
            z-index: -1;
        }

        .parallax-element {
            position: absolute;
            will-change: transform;
            font-size: 2rem;
            opacity: 0.5;
        }

        /* Navbar */
        .navbar {
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(10, 25, 47, 0.9);
            backdrop-filter: blur(10px);
        }

        .logo {
            font-weight: bold;
            font-size: 1.5rem;
            color: white;
            text-decoration: none;
        }

        .logo span {
            color: var(--accent-orange);
        }

        /* Main Content */
        .login-container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
        }

        .login-box {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 3rem;
            width: 100%;
            max-width: 450px;
            backdrop-filter: blur(10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            transform-style: preserve-3d;
            perspective: 1000px;
            position: relative;
        }

        .form-title {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            text-align: center;
            color: white;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-control {
            width: 100%;
            padding: 1rem;
            border-radius: 5px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.05);
            color: white;
            font-size: 1rem;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent-orange);
            background: rgba(255, 255, 255, 0.1);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .login-btn {
            background: var(--accent-orange);
            padding: 1rem;
            border-radius: 50px;
            font-weight: bold;
            transition: transform 0.3s, box-shadow 0.3s;
            display: block;
            width: 100%;
            cursor: pointer;
            color: white;
            text-decoration: none;
            border: none;
            font-size: 1rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 111, 0, 0.4);
        }

        .login-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
            font-size: 0.9rem;
        }

        .login-footer a {
            color: var(--accent-orange);
            text-decoration: none;
            transition: color 0.3s;
        }

        .login-footer a:hover {
            color: white;
        }

        .social-login {
            margin: 2rem 0;
            text-align: center;
            position: relative;
        }

        .social-login::before,
        .social-login::after {
            content: '';
            position: absolute;
            top: 50%;
            width: 40%;
            height: 1px;
            background: rgba(255, 255, 255, 0.2);
        }

        .social-login::before {
            left: 0;
        }

        .social-login::after {
            right: 0;
        }

        .social-buttons {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.3s, background 0.3s;
        }

        .social-btn:hover {
            transform: translateY(-3px);
            background: rgba(255, 255, 255, 0.2);
        }

        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .remember-me input {
            margin-right: 0.5rem;
        }

        /* Footer */
        .mini-footer {
            background: rgba(0, 0, 0, 0.3);
            text-align: center;
            padding: 1.5rem;
            font-size: 0.9rem;
        }

        .toggle-password {
            position: absolute;
            right: 10px;
            top: 12px;
            cursor: pointer;
            color: rgba(255, 255, 255, 0.5);
        }

        /* Animation classes */
        .slide-up {
            opacity: 0;
            transform: translateY(50px);
        }

        @media (max-width: 768px) {
            .login-box {
                padding: 2rem;
            }
        }
    </style>
</head>

<body>
    <!-- Floating Background Elements -->
    <div class="floating-icons">
        <div class="parallax-element" id="icon1" style="top: 15%; left: 10%;">📚</div>
        <div class="parallax-element" id="icon2" style="top: 60%; left: 85%;">🎯</div>
        <div class="parallax-element" id="icon3" style="top: 75%; left: 25%;">🏆</div>
        <div class="parallax-element" id="icon4" style="top: 20%; left: 80%;">📝</div>
        <div class="parallax-element" id="icon5" style="top: 85%; left: 70%;">🔍</div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <a href="index.php" class="logo">Exam<span>verse</span></a>
        <a href="index.php" style="color: white; text-decoration: none;">Back to Home</a>
    </nav>

    <!-- Main Content -->
    <div class="login-container">
        <div class="login-box slide-up">
            <h2 class="form-title">Welcome Back</h2>
            <?php if (isset($error))
                echo "<p class='text-danger'>$error</p>"; ?>
            <form id="login-form" method="POST" action="login.php">
                <div class="form-group">
                    <input type="email" name="email" class="form-control" id="email" placeholder="Email Address"
                        required>
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password"
                        required>
                    <span class="toggle-password material-icons">visibility_off</span>
                </div>
                <div class="remember-me">
                    <input type="checkbox" id="remember-me">
                    <label for="remember-me">Remember me</label>
                </div>
                <button type="submit" class="login-btn">Login</button>

                <div class="social-login">
                    <span>Or login with</span>
                </div>

                <div class="social-buttons">
                    <div class="social-btn" title="Login with Google">
                        <i class="material-icons">mail</i>
                    </div>
                    <div class="social-btn" title="Login with Facebook">
                        <i class="material-icons">facebook</i>
                    </div>
                    <div class="social-btn" title="Login with Apple">
                        <i class="material-icons">phone_iphone</i>
                    </div>
                </div>

                <div class="login-footer">
                    <a href="forgot-password.html">Forgot Password?</a>
                    <a href="signup.php">Create Account</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="mini-footer">
        <p>&copy; 2025 Examverse. All rights reserved.</p>
    </footer>

    <!-- JavaScript -->
    <script>
        // Animation for login box
        window.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                document.querySelector('.login-box').classList.remove('slide-up');
            }, 200);
        });

        // Parallax Effect for Floating Icons
        document.addEventListener('mousemove', (e) => {
            const elements = document.querySelectorAll('.parallax-element');
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;

            elements.forEach(element => {
                const speed = Math.random() * 0.1 + 0.05;
                const offsetX = (mouseX - 0.5) * 100 * speed;
                const offsetY = (mouseY - 0.5) * 100 * speed;

                element.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
            });
        });

        // Password visibility toggle
        const togglePassword = document.querySelector('.toggle-password');
        const passwordInput = document.querySelector('#password');

        togglePassword.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            togglePassword.textContent = type === 'password' ? 'visibility_off' : 'visibility';
        });

        // 3D effect for login box
        const loginBox = document.querySelector('.login-box');

        document.addEventListener('mousemove', (e) => {
            const loginBoxRect = loginBox.getBoundingClientRect();
            const loginBoxCenterX = loginBoxRect.left + loginBoxRect.width / 2;
            const loginBoxCenterY = loginBoxRect.top + loginBoxRect.height / 2;

            const mouseX = e.clientX;
            const mouseY = e.clientY;

            const offsetX = (mouseX - loginBoxCenterX) / 20;
            const offsetY = (mouseY - loginBoxCenterY) / 20;

            loginBox.style.transform = `rotateY(${offsetX}deg) rotateX(${-offsetY}deg)`;
        });

        loginBox.addEventListener('mouseleave', () => {
            gsap.to(loginBox, {
                rotateX: 0,
                rotateY: 0,
                duration: 0.5,
                ease: 'power2.out'
            });
        });

    </script>
</body>

</html>