<?php
session_start(); // Start session at the top

// Database Connection
$host = "localhost";
$username = "root";
$password = "";
$database = "govt_exams";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for form validation
$errors = [];
$formData = [
    'name' => '',
    'email' => '',
    'qualification' => ''
];

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $formData['name'] = htmlspecialchars(trim($_POST["name"]));
    $formData['email'] = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $formData['qualification'] = htmlspecialchars(trim($_POST["qualification"]));
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];

    // Validate required fields
    if (empty($formData['name'])) {
        $errors['name'] = "Name is required.";
    }
    if (empty($formData['qualification'])) {
        $errors['qualification'] = "Qualification is required.";
    }

    // Email validation
    if (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address.";
    } else {
        // Check if email already exists
        $checkEmail = "SELECT id FROM users WHERE email = ?";
        $stmt = $conn->prepare($checkEmail);
        if ($stmt) {
            $stmt->bind_param("s", $formData['email']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $errors['email'] = "Email already registered. Please use a different email or login.";
            }
            $stmt->close();
        } else {
            $errors['db'] = "Database error: " . $conn->error;
        }
    }

    // Password validation
    if (strlen($password) < 8) {
        $errors['password'] = "Password must be at least 8 characters long.";
    }

    // Password confirmation
    if ($password !== $confirmPassword) {
        $errors['confirm_password'] = "Passwords do not match.";
    }

    // If no errors, proceed with registration
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Insert into Database
        $sql = "INSERT INTO users (name, email, password, qualification, created_at) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            $errors['db'] = "Database error: " . $conn->error;
        } else {
            $stmt->bind_param("ssss", $formData['name'], $formData['email'], $hashedPassword, $formData['qualification']);
            if ($stmt->execute()) {
                // Send welcome email
                require 'vendor/autoload.php'; // Path to Composer autoload

                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'abc@gmail.com'; // Your Gmail address
                    $mail->Password = 'abc@gmail.com'; // Your Gmail App Password
                    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom('noreply@Exam alert.com', 'Exam alert');
                    $mail->addAddress($formData['email'], $formData['name']);

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Welcome to Exam alert!';
                    $mail->Body = "
                        <h1>Welcome, {$formData['name']}!</h1>
                        <p>Your Exam alert account has been successfully created.</p>
                        <p>Get started with:</p>
                        <ul>
                            <li>Comprehensive study materials</li>
                            <li>Practice tests &amp; mock exams</li>
                            <li>Personalized progress tracking</li>
                        </ul>
                        <p>Happy learning!<br>Exam alert Team</p>
                    ";
                    $mail->AltBody = "Welcome {$formData['name']}!\n\nYour Exam alert account is ready. Start your exam preparation journey with our resources and tools.\n\nExam alert Team";

                    $mail->send();
                } catch (Exception $e) {
                    error_log("Email sending failed: " . $mail->ErrorInfo);
                }

                // Registration successful - redirect to login page
                $_SESSION['registration_success'] = true;
                header("Location: login.php?signup=success");
                exit();
            } else {
                $errors['db'] = "Registration failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Exam alert - Your Government Exam Preparation Platform</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a6bdf;
            --secondary-color: #5d87ff;
            --accent-color: #7b68ee;
            --light-bg: #f8f9fc;
            --dark-text: #2c3e50;
        }

        body {
            background-color: var(--light-bg);
            color: var(--dark-text);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .logo {
            max-height: 50px;
            margin-bottom: 15px;
        }

        .Exam alert-card {
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            border: none;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            text-align: center;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
        }

        .btn-Exam alert {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
            font-weight: 600;
            padding: 10px 15px;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .btn-Exam alert:hover {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #e2e8f0;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(93, 135, 255, 0.25);
        }

        .form-label {
            font-weight: 600;
            color: var(--dark-text);
        }

        .error-message {
            color: #dc3545;
            font-size: 0.85rem;
            margin-top: 5px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .feature-icon {
            margin-right: 10px;
            color: var(--primary-color);
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #6c757d;
        }

        .divider::before,
        .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #e2e8f0;
        }

        .divider::before {
            margin-right: 10px;
        }

        .divider::after {
            margin-left: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-7 d-none d-md-block">
                <div class="d-flex flex-column justify-content-center h-100 px-4">
                    <h1 class="display-5 fw-bold text-primary mb-4">Welcome to Exam alert</h1>
                    <p class="lead mb-4">Your comprehensive platform for government exam preparation. Join thousands of
                        aspirants who have successfully cleared their exams with our guidance.</p>
                    <div class="mt-4">
                        <div class="feature-item">
                            <i class="fas fa-check-circle feature-icon"></i>
                            <span>Access to comprehensive study materials and mock tests</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle feature-icon"></i>
                            <span>Personalized exam preparation strategy</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle feature-icon"></i>
                            <span>Expert guidance from toppers and subject specialists</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-check-circle feature-icon"></i>
                            <span>Regular updates on upcoming government job notifications</span>
                        </div>
                    </div>
                    <div class="mt-4">
                        <img src="/api/placeholder/600/320" alt="Exam alert Platform Preview"
                            class="img-fluid rounded shadow">
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card Exam alert-card">
                    <div class="card-header py-3">
                        <img src="/api/placeholder/150/50" alt="Exam alert Logo" class="logo">
                        <h3 class="mb-0">Create Your Account</h3>
                    </div>
                    <div class="card-body p-4">
                        <?php if (!empty($errors['db'])): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $errors['db']; ?>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="signup.php">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo $formData['name']; ?>" required>
                                </div>
                                <?php if (isset($errors['name'])): ?>
                                    <div class="error-message"><?php echo $errors['name']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" name="email" class="form-control"
                                        value="<?php echo $formData['email']; ?>" required>
                                </div>
                                <?php if (isset($errors['email'])): ?>
                                    <div class="error-message"><?php echo $errors['email']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <div class="input-group position-relative">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" name="password" id="password" class="form-control" required>
                                    <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                                </div>
                                <?php if (isset($errors['password'])): ?>
                                    <div class="error-message"><?php echo $errors['password']; ?></div>
                                <?php endif; ?>
                                <div class="form-text">Must be at least 8 characters long</div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Confirm Password</label>
                                <div class="input-group position-relative">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" name="confirm_password" id="confirmPassword"
                                        class="form-control" required>
                                    <i class="fas fa-eye password-toggle" id="toggleConfirmPassword"></i>
                                </div>
                                <?php if (isset($errors['confirm_password'])): ?>
                                    <div class="error-message"><?php echo $errors['confirm_password']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Educational Qualification</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-graduation-cap"></i></span>
                                    <select name="qualification" class="form-control" required>
                                        <option value="" disabled <?php echo empty($formData['qualification']) ? 'selected' : ''; ?>>Select your highest qualification</option>
                                        <option value="High School" <?php echo $formData['qualification'] == 'High School' ? 'selected' : ''; ?>>High School</option>
                                        <option value="Bachelor's Degree" <?php echo $formData['qualification'] == "Bachelor's Degree" ? 'selected' : ''; ?>>
                                            Bachelor's Degree</option>
                                        <option value="Master's Degree" <?php echo $formData['qualification'] == "Master's Degree" ? 'selected' : ''; ?>>Master's Degree</option>
                                        <option value="PhD" <?php echo $formData['qualification'] == 'PhD' ? 'selected' : ''; ?>>PhD</option>
                                        <option value="Other" <?php echo $formData['qualification'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <?php if (isset($errors['qualification'])): ?>
                                    <div class="error-message"><?php echo $errors['qualification']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="termsCheck" required>
                                <label class="form-check-label" for="termsCheck">
                                    I agree to the <a href="#" class="text-decoration-none">Terms of Service</a> and <a
                                        href="#" class="text-decoration-none">Privacy Policy</a>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-Exam alert w-100 mb-3">
                                <i class="fas fa-user-plus me-2"></i>Create Account
                            </button>
                            <div class="divider">OR</div>
                            <div class="d-grid gap-2 mb-3">
                                <button type="button" class="btn btn-outline-primary">
                                    <i class="fab fa-google me-2"></i>Sign up with Google
                                </button>
                            </div>
                            <p class="text-center mb-0">Already have an account? <a href="login.php"
                                    class="text-decoration-none fw-bold">Login here</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function () {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
        document.getElementById('toggleConfirmPassword').addEventListener('click', function () {
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const type = confirmPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            confirmPasswordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>

</html>