<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Central</title>
    <link href="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.css" rel="stylesheet">
    <script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #1a237e;
            --accent-orange: #ff6f00;
            --dark-bg: #0a192f;
            --card-bg: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(45deg, var(--dark-bg), #16213e);
            color: white;
            overflow-x: hidden;
        }

        /* Global Section Styling */
        section {
            padding: 5rem 2rem;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            perspective: 1000px;
            padding: 0 2rem;
        }

        .hero-content {
            position: relative;
            z-index: 1;
            transform-style: preserve-3d;
        }

        /* Exam Grid Section */
        .exam-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .exam-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 2rem;
            backdrop-filter: blur(10px);
            transform-style: preserve-3d;
            transition: transform 0.3s;
            cursor: pointer;
        }

        .exam-card:hover {
            transform: translateZ(20px) rotateX(5deg) rotateY(5deg);
        }

        /* Floating Elements */
        .floating-icons {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
            top: 0;
            left: 0;
        }

        .parallax-element {
            position: absolute;
            will-change: transform;
            font-size: 2rem;
        }

        /* CTA Button */
        .cta-button {
            background: var(--accent-orange);
            padding: 1rem 2rem;
            border-radius: 50px;
            font-weight: bold;
            transition: transform 0.3s;
            display: inline-block;
            margin-top: 2rem;
            cursor: pointer;
            color: white;
            text-decoration: none;
        }

        .cta-button:hover {
            transform: translateY(-5px) scale(1.05);
        }

        /* Section Titles */
        .section-title {
            font-size: 3rem;
            margin-bottom: 3rem;
            text-align: center;
            position: relative;
            display: inline-block;
            left: 50%;
            transform: translateX(-50%);
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 3px;
            background: var(--accent-orange);
        }

        /* Features Section */
        .features-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .feature-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            backdrop-filter: blur(10px);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--accent-orange);
        }

        /* Testimonials Section */
        .testimonials-container {
            max-width: 1000px;
            margin: 0 auto;
            position: relative;
        }

        .testimonial-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 2rem;
            margin: 0 auto;
            max-width: 800px;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .testimonial-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 1rem;
            background: #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }

        .testimonial-quote {
            font-style: italic;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        /* Statistics Section */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            text-align: center;
        }

        .stat-item {
            padding: 2rem;
        }

        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            color: var(--accent-orange);
            margin-bottom: 0.5rem;
        }

        /* Pricing Section */
        .pricing-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .pricing-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            backdrop-filter: blur(10px);
            transition: transform 0.3s;
            display: flex;
            flex-direction: column;
        }

        .pricing-card.featured {
            border: 2px solid var(--accent-orange);
            transform: scale(1.05);
        }

        .pricing-card.featured:hover {
            transform: scale(1.1);
        }

        .pricing-card:hover {
            transform: translateY(-10px);
        }

        .pricing-header {
            margin-bottom: 2rem;
        }

        .pricing-price {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--accent-orange);
            margin: 1rem 0;
        }

        .pricing-features {
            margin: 2rem 0;
            text-align: left;
            flex-grow: 1;
        }

        .pricing-feature {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
        }

        .pricing-feature i {
            color: var(--accent-orange);
            margin-right: 0.5rem;
        }

        /* Footer Section */
        .footer {
            background: rgba(0, 0, 0, 0.3);
            text-align: center;
            padding: 3rem 2rem;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
            text-align: left;
        }

        .footer-heading {
            font-size: 1.2rem;
            margin-bottom: 1rem;
            color: var(--accent-orange);
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 0.5rem;
        }

        .footer-links a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: var(--accent-orange);
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin: 2rem 0;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--card-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s;
        }

        .social-icon:hover {
            transform: translateY(-5px);
        }

        /* Newsletter Form */
        .newsletter-form {
            max-width: 500px;
            margin: 0 auto;
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
        }

        .newsletter-input {
            padding: 1rem;
            border-radius: 50px;
            border: none;
            flex-grow: 1;
            min-width: 200px;
        }

        /* FAQ Section */
        .faq-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .faq-item {
            background: var(--card-bg);
            border-radius: 15px;
            margin-bottom: 1rem;
            overflow: hidden;
        }

        .faq-question {
            padding: 1.5rem;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: bold;
        }

        .faq-answer {
            padding: 0 1.5rem 1.5rem;
            display: none;
        }

        .faq-question.active+.faq-answer {
            display: block;
        }

        /* Contact Section */
        .contact-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .contact-form {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-control {
            width: 100%;
            padding: 1rem;
            border-radius: 5px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .contact-item {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .contact-item i {
            margin-right: 1rem;
            color: var(--accent-orange);
        }

        /* Responsive Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
            transition: background 0.3s;
        }

        .navbar.scrolled {
            background: rgba(10, 25, 47, 0.9);
            backdrop-filter: blur(10px);
        }

        .logo {
            font-weight: bold;
            font-size: 1.5rem;
            color: white;
            text-decoration: none;
        }

        .logo span {
            color: var(--accent-orange);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--accent-orange);
        }

        .mobile-menu-btn {
            display: none;
            cursor: pointer;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                position: fixed;
                top: 0;
                right: -100%;
                height: 100vh;
                width: 70%;
                background: var(--dark-bg);
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: right 0.3s;
            }

            .nav-links.active {
                right: 0;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="#" class="logo">Exam<span>-Central</span></a>
        <ul class="nav-links">
            <li><a href="#hero">Home</a></li>
            <li><a href="#exams">Exams</a></li>
            <li><a href="#features">Features</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
        <button class="mobile-menu-btn">
            <i class="material-icons">menu</i>
        </button>
    </nav>

    <!-- Floating Background Elements -->
    <div class="floating-icons">
        <div class="parallax-element" id="icon1" style="top: 20%; left: 10%;">📚</div>
        <div class="parallax-element" id="icon2" style="top: 50%; left: 80%;">🎯</div>
        <div class="parallax-element" id="icon3" style="top: 80%; left: 30%;">🏆</div>
        <div class="parallax-element" id="icon4" style="top: 30%; left: 70%;">📝</div>
        <div class="parallax-element" id="icon5" style="top: 70%; left: 60%;">🔍</div>
        <div class="parallax-element" id="icon6" style="top: 40%; left: 20%;">📊</div>
    </div>

    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-content">
            <h1 class="mdc-typography--headline1">Transform Your<br>Government Career Journey</h1>
            <p class="mdc-typography--subtitle1">3D Interactive Platform for UPSC, SSC, Banking & More</p>
            <a href="#" class="cta-button">Start Free Trial</a>
        </div>
    </section>

    <!-- Exam Grid Section -->
    <section class="exam-section" id="exams">
        <h2 class="section-title">Featured Exams</h2>
        <div class="exam-grid">
            <div class="exam-card">
                <h3>UPSC Civil Services</h3>
                <p>Comprehensive IAS/IPS preparation</p>
                <div class="mdc-chip-set">
                    <div class="mdc-chip">Prelims</div>
                    <div class="mdc-chip">Mains</div>
                    <div class="mdc-chip">Interview</div>
                </div>
            </div>
            <div class="exam-card">
                <h3>SSC CGL</h3>
                <p>Complete Staff Selection Commission preparation</p>
                <div class="mdc-chip-set">
                    <div class="mdc-chip">Tier I</div>
                    <div class="mdc-chip">Tier II</div>
                    <div class="mdc-chip">Tier III</div>
                </div>
            </div>
            <div class="exam-card">
                <h3>Bank PO</h3>
                <p>Probationary Officer exam preparation</p>
                <div class="mdc-chip-set">
                    <div class="mdc-chip">Prelims</div>
                    <div class="mdc-chip">Mains</div>
                    <div class="mdc-chip">Interview</div>
                </div>
            </div>
            <div class="exam-card">
                <h3>Railways RRB</h3>
                <p>Railway Recruitment Board exams</p>
                <div class="mdc-chip-set">
                    <div class="mdc-chip">NTPC</div>
                    <div class="mdc-chip">Group D</div>
                    <div class="mdc-chip">ALP</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section" id="features">
        <h2 class="section-title">Why Choose Exam alert</h2>
        <div class="features-container">
            <div class="feature-card">
                <i class="material-icons feature-icon">school</i>
                <h3>Expert Faculty</h3>
                <p>Learn from India's best educators with proven track records in government examinations</p>
            </div>
            <div class="feature-card">
                <i class="material-icons feature-icon">analytics</i>
                <h3>AI-Powered Analysis</h3>
                <p>Get personalized insights and improvement areas based on your performance</p>
            </div>
            <div class="feature-card">
                <i class="material-icons feature-icon">library_books</i>
                <h3>Vast Question Bank</h3>
                <p>Practice with over 100,000 questions across all major government exams</p>
            </div>
            <div class="feature-card">
                <i class="material-icons feature-icon">group</i>
                <h3>Community Support</h3>
                <p>Connect with fellow aspirants and mentors in our vibrant community</p>
            </div>
            <div class="feature-card">
                <i class="material-icons feature-icon">timer</i>
                <h3>Mock Tests</h3>
                <p>Realistic exam environment with timed tests and detailed analytics</p>
            </div>
            <div class="feature-card">
                <i class="material-icons feature-icon">devices</i>
                <h3>Multi-device Access</h3>
                <p>Seamlessly switch between desktop, tablet, and mobile devices</p>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
        <div class="stats-container">
            <div class="stat-item">
                <div class="stat-number" id="stat1">50,000+</div>
                <div class="stat-label">Active Students</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="stat2">200+</div>
                <div class="stat-label">Expert Faculty</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="stat3">5,000+</div>
                <div class="stat-label">Success Stories</div>
            </div>
            <div class="stat-item">
                <div class="stat-number" id="stat4">25+</div>
                <div class="stat-label">Exam Categories</div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials-section" id="testimonials">
        <h2 class="section-title">Success Stories</h2>
        <div class="testimonials-container">
            <div class="testimonial-card">
                <div class="testimonial-avatar">👨‍💼</div>
                <p class="testimonial-quote">"Exam alert's structured approach and mock tests were instrumental in my
                    UPSC success. The mentorship program gave me the edge I needed."</p>
                <h4>Rahul Sharma</h4>
                <p>AIR 45, UPSC CSE 2023</p>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section class="pricing-section" id="pricing">
        <h2 class="section-title">Choose Your Plan</h2>
        <div class="pricing-container">
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Basic</h3>
                    <div class="pricing-price">₹999<span>/month</span></div>
                    <p>Perfect for beginners</p>
                </div>
                <div class="pricing-features">
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Access to 10+ exam categories</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Basic study materials</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>5 mock tests per month</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Community access</span>
                    </div>
                </div>
                <a href="#" class="cta-button">Get Started</a>
            </div>
            <div class="pricing-card featured">
                <div class="pricing-header">
                    <h3>Premium</h3>
                    <div class="pricing-price">₹1,999<span>/month</span></div>
                    <p>Most Popular</p>
                </div>
                <div class="pricing-features">
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Access to all exam categories</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Advanced study materials</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Unlimited mock tests</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>1-on-1 mentoring (2 sessions/month)</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Performance analytics</span>
                    </div>
                </div>
                <a href="#" class="cta-button">Get Started</a>
            </div>
            <div class="pricing-card">
                <div class="pricing-header">
                    <h3>Ultimate</h3>
                    <div class="pricing-price">₹3,999<span>/month</span></div>
                    <p>For serious aspirants</p>
                </div>
                <div class="pricing-features">
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>All Premium features</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Weekly 1-on-1 mentoring</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Interview preparation</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Personalized study plan</span>
                    </div>
                    <div class="pricing-feature">
                        <i class="material-icons">check_circle</i>
                        <span>Priority doubt solving</span>
                    </div>
                </div>
                <a href="#" class="cta-button">Get Started</a>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
        <h2 class="section-title">Frequently Asked Questions</h2>
        <div class="faq-container">
            <div class="faq-item">
                <div class="faq-question">
                    <span>How is Exam alert different from other platforms?</span>
                    <i class="material-icons">expand_more</i>
                </div>
                <div class="faq-answer">
                    <p>Exam alert offers a unique 3D interactive learning experience with AI-powered personalization,
                        expert faculty, and a comprehensive approach covering all aspects of government exam
                        preparation.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    <span>Can I access the platform on mobile devices?</span>
                    <i class="material-icons">expand_more</i>
                </div>
                <div class="faq-answer">
                    <p>Yes, Exam alert is fully responsive and works seamlessly across desktops, tablets, and mobile
                        phones, allowing you to study anytime, anywhere.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    <span>Do you offer refunds if I'm not satisfied?</span>
                    <i class="material-icons">expand_more</i>
                </div>
                <div class="faq-answer">
                    <p>We offer a 7-day money-back guarantee for all new subscriptions if you're not completely
                        satisfied with our platform.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    <span>How often is the content updated?</span>
                    <i class="material-icons">expand_more</i>
                </div>
                <div class="faq-answer">
                    <p>Our content is continuously updated by our expert team to reflect the latest exam patterns,
                        syllabus changes, and current affairs relevant to government exams.</p>
                </div>
            </div>
            <div class="faq-item">
                <div class="faq-question">
                    <span>Can I switch between plans?</span>
                    <i class="material-icons">expand_more</i>
                </div>
                <div class="faq-answer">
                    <p>Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next
                        billing cycle.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section" id="contact">
        <h2 class="section-title">Get In Touch</h2>
        <div class="contact-container">
            <form class="contact-form">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Your Name">
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email">
                </div>
                <div class="form-group">
                    <select class="form-control">
                        <option selected disabled>Select Subject</option>
                        <option>General Inquiry</option>
                        <option>Technical Support</option>
                        <option>Billing Question</option>
                        <option>Feedback</option>
                    </select>
                </div>
                <div class="form-group">
                    <textarea class="form-control" rows="4" placeholder="Your Message"></textarea>
                </div>
                <button type="submit" class="cta-button">Send Message</button>
            </form>
            <div class="contact-info">
                <div class="contact-item">
                    <i class="material-icons">location_on</i>
                    <div>
                        <h4>Address</h4>
                        <p>123 Education Lane, New Delhi, India</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="material-icons">phone</i>
                    <div>
                        <h4>Phone</h4>
                        <p>+91 98765 43210</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="material-icons">email</i>
                    <div>
                        <h4>Email</h4>
                        <p>support@Exam alert.com</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="material-icons">access_time</i>
                    <div>
                        <h4>Working Hours</h4>
                        <p>Monday-Saturday: 9am-7pm</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="newsletter-section">
        <h2 class="section-title">Subscribe to Our Newsletter</h2>
        <p style="text-align: center; max-width: 600px; margin: 0 auto 2rem;">Get the latest exam updates, study tips,
            and exclusive offers delivered to your inbox.</p>
        <form class="newsletter-form">
            <input type="email" class="newsletter-input" placeholder="Your Email Address">
            <button type="submit" class="cta-button">Subscribe</button>
        </form>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="footer-grid">
            <div class="footer-column">
                <h3 class="footer-heading">Exam alert</h3>
                <p>Your gateway to government careers with Exam alert, interactive exam preparation.</p>
                <div class="social-icons">
                    <a href="#" class="social-icon"><i class="material-icons">facebook</i></a>
                    <a href="#" class="social-icon"><i class="material-icons">twitter</i></a>
                    <a href="#" class="social-icon"><i class="material-icons">instagram</i></a>
                    <a href="#" class="social-icon"><i class="material-icons">linkedin</i></a>
                    <a href="#" class="social-icon"><i class="material-icons">youtube</i></a>
                </div>
            </div>
            <div class="footer-column">
                <h3 class="footer-heading">Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="#hero">Home</a></li>
                    <li><a href="#exams">Exams</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#pricing">Pricing</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3 class="footer-heading">Popular Exams</h3>
                <ul class="footer-links">
                    <li><a href="#">UPSC Civil Services</a></li>
                    <li><a href="#">SSC CGL</a></li>
                    <li><a href="#">Bank PO</a></li>
                    <li><a href="#">Railway RRB</a></li>
                    <li><a href="#">State PCS</a></li>
                    <li><a href="#">Defense Exams</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3 class="footer-heading">Support</h3>
                <ul class="footer-links">
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">Community</a></li>
                    <li><a href="#">Terms of Service</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Refund Policy</a></li>
                    <li><a href="#">Student Login</a></li>
                </ul>
            </div>
        </div>
        <div class="copyright">
            <p>&copy; 2025 Exam alert. All rights reserved.</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const navLinks = document.querySelector('.nav-links');

        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });

        // Navbar Scroll Effect
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Initialize GSAP ScrollTrigger
        gsap.registerPlugin(ScrollTrigger);

        // Hero Animation
        gsap.from('.hero-content', {
            opacity: 0,
            y: 100,
            duration: 1.5,
            ease: 'power3.out'
        });

        // Parallax Effect for Floating Icons
        document.addEventListener('mousemove', (e) => {
            const elements = document.querySelectorAll('.parallax-element');
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;

            elements.forEach(element => {
                const speed = Math.random() * 0.1 + 0.05;
                const offsetX = (mouseX - 0.5) * 100 * speed;
                const offsetY = (mouseY - 0.5) * 100 * speed;

                element.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
            });
        });

        // Exam Cards Animation
        gsap.from('.exam-card', {
            scrollTrigger: {
                trigger: '.exam-section',
                start: 'top 80%',
            },
            opacity: 0,
            y: 50,
            stagger: 0.2,
            duration: 1,
            ease: 'power2.out'
        });

        // Feature Cards Animation
        gsap.from('.feature-card', {
            scrollTrigger: {
                trigger: '.features-section',
                start: 'top 80%',
            },
            opacity: 0,
            y: 50,
            stagger: 0.1,
            duration: 0.8,
            ease: 'power2.out'
        });

        // Stats Counter Animation
        const statsElements = document.querySelectorAll('.stat-number');

        statsElements.forEach(stat => {
            const originalText = stat.textContent;
            let value;

            if (originalText.includes('+')) {
                value = parseInt(originalText.replace(/,|\+/g, ''));
            } else {
                value = parseInt(originalText.replace(/,/g, ''));
            }

            stat.textContent = '0';

            ScrollTrigger.create({
                trigger: '.stats-section',
                start: 'top 80%',
                onEnter: () => {
                    let counter = { value: 0 };

                    gsap.to(counter, {
                        value: value,
                        duration: 2,
                        ease: 'power2.out',
                        onUpdate: () => {
                            let currentValue = Math.floor(counter.value);
                            if (originalText.includes('+')) {
                                stat.textContent = currentValue.toLocaleString() + '+';
                            } else {
                                stat.textContent = currentValue.toLocaleString();
                            }
                        }
                    });
                }
            });
        });

        // Testimonial Animation
        gsap.from('.testimonial-card', {
            scrollTrigger: {
                trigger: '.testimonials-section',
                start: 'top 80%',
            },
            opacity: 0,
            scale: 0.9,
            duration: 1,
            ease: 'back.out(1.7)'
        });

        // Pricing Cards Animation
        gsap.from('.pricing-card', {
            scrollTrigger: {
                trigger: '.pricing-section',
                start: 'top 80%',
            },
            opacity: 0,
            y: 30,
            stagger: 0.2,
            duration: 0.8,
            ease: 'power2.out'
        });

        // FAQ Toggle
        const faqQuestions = document.querySelectorAll('.faq-question');

        faqQuestions.forEach(question => {
            question.addEventListener('click', () => {
                // Toggle active class
                question.classList.toggle('active');

                // Toggle icon
                const icon = question.querySelector('.material-icons');
                if (question.classList.contains('active')) {
                    icon.textContent = 'expand_less';
                } else {
                    icon.textContent = 'expand_more';
                }

                // Show/hide answer with animation
                const answer = question.nextElementSibling;
                if (question.classList.contains('active')) {
                    gsap.to(answer, {
                        height: 'auto',
                        duration: 0.3,
                        ease: 'power2.out',
                        onStart: () => {
                            answer.style.display = 'block';
                        }
                    });
                } else {
                    gsap.to(answer, {
                        height: 0,
                        duration: 0.3,
                        ease: 'power2.in',
                        onComplete: () => {
                            answer.style.display = 'none';
                        }
                    });
                }
            });
        });

        // Contact Form Animation
        gsap.from('.contact-form, .contact-info', {
            scrollTrigger: {
                trigger: '.contact-section',
                start: 'top 80%',
            },
            opacity: 0,
            x: (index) => index === 0 ? -50 : 50,
            duration: 1,
            stagger: 0.3,
            ease: 'power2.out'
        });

        // Newsletter Animation
        gsap.from('.newsletter-section h2, .newsletter-section p, .newsletter-form', {
            scrollTrigger: {
                trigger: '.newsletter-section',
                start: 'top 80%',
            },
            opacity: 0,
            y: 30,
            stagger: 0.2,
            duration: 0.8,
            ease: 'power2.out'
        });

        // Form submission handling (prevent default for demo)
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                alert('Form submission successful! (Demo only)');
                form.reset();
            });
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();

                const targetId = this.getAttribute('href');
                if (targetId === '#') return;

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 70,
                        behavior: 'smooth'
                    });

                    // Close mobile menu if open
                    if (navLinks.classList.contains('active')) {
                        navLinks.classList.remove('active');
                    }
                }
            });
        });

        // 3D tilt effect for cards
        const cards = document.querySelectorAll('.exam-card, .feature-card, .pricing-card');

        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const xPercent = x / rect.width;
                const yPercent = y / rect.height;

                const rotateX = (0.5 - yPercent) * 10;
                const rotateY = (xPercent - 0.5) * 10;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });

        // Add active class to current section in navigation
        window.addEventListener('scroll', () => {
            const sections = document.querySelectorAll('section');
            const navLinks = document.querySelectorAll('.nav-links a');

            let current = '';

            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;

                if (pageYOffset >= sectionTop - 100) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>

</html>