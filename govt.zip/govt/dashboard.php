<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "govt_exams";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize search variables
$search_term = "";
$search_category = "all";
$filter_age = "";
$filter_qualification = "";

// Process search when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_term = $_POST["search_term"] ?? "";
    $search_category = $_POST["search_category"] ?? "all";
    $filter_age = $_POST["filter_age"] ?? "";
    $filter_qualification = $_POST["filter_qualification"] ?? "";
}

// Build the SQL query based on search parameters
$sql = "SELECT * FROM government_exams WHERE 1=1";

if (!empty($search_term)) {
    if ($search_category == "all") {
        $sql .= " AND (exam_name LIKE '%$search_term%' 
                 OR academic_qualification LIKE '%$search_term%' 
                 OR official_website LIKE '%$search_term%')";
    } else {
        $sql .= " AND $search_category LIKE '%$search_term%'";
    }
}

if (!empty($filter_age)) {
    switch ($filter_age) {
        case "18-25":
            $sql .= " AND (age_limit LIKE '%18%' OR age_limit LIKE '%19%' OR age_limit LIKE '%20%' 
                  OR age_limit LIKE '%21%' OR age_limit LIKE '%22%' OR age_limit LIKE '%23%' 
                  OR age_limit LIKE '%24%' OR age_limit LIKE '%25%')";
            break;
        case "26-30":
            $sql .= " AND (age_limit LIKE '%26%' OR age_limit LIKE '%27%' OR age_limit LIKE '%28%' 
                  OR age_limit LIKE '%29%' OR age_limit LIKE '%30%')";
            break;
        case "30+":
            $sql .= " AND (age_limit LIKE '%3%' OR age_limit LIKE '%4%' OR age_limit LIKE '%5%' 
                  OR age_limit LIKE '%no age%' OR age_limit LIKE '%No age%')";
            break;
        case "no-limit":
            $sql .= " AND (age_limit LIKE '%no age%' OR age_limit LIKE '%No age%')";
            break;
    }
}

if (!empty($filter_qualification)) {
    $sql .= " AND academic_qualification LIKE '%$filter_qualification%'";
}

// Execute the query
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam alert</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen">
    <!-- Navigation Bar -->
    <nav class="bg-blue-800 text-white shadow-md">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div>
                    <a href="#" class="text-xl font-bold">Exam-alert</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="logout.php"
                        class="ml-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-center text-blue-800 mb-8">Indian Government Exams Search</h1>

        <!-- Search Form -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="space-y-4">
                <div class="flex flex-col md:flex-row gap-4">
                    <div class="flex-1">
                        <label for="search_term" class="block text-gray-700 mb-2">Search Term:</label>
                        <input type="text" id="search_term" name="search_term"
                            value="<?php echo htmlspecialchars($search_term); ?>"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="md:w-1/4">
                        <label for="search_category" class="block text-gray-700 mb-2">Search In:</label>
                        <select id="search_category" name="search_category"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="all" <?php if ($search_category == "all")
                                echo "selected"; ?>>All Fields
                            </option>
                            <option value="exam_name" <?php if ($search_category == "exam_name")
                                echo "selected"; ?>>Exam
                                Name</option>
                            <option value="academic_qualification" <?php if ($search_category == "academic_qualification")
                                echo "selected"; ?>>Qualification</option>
                            <option value="age_limit" <?php if ($search_category == "age_limit")
                                echo "selected"; ?>>Age
                                Limit</option>
                        </select>
                    </div>
                </div>

                <div class="flex flex-col md:flex-row gap-4">
                    <div class="md:w-1/2">
                        <label for="filter_age" class="block text-gray-700 mb-2">Filter by Age:</label>
                        <select id="filter_age" name="filter_age"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="" <?php if ($filter_age == "")
                                echo "selected"; ?>>All Ages</option>
                            <option value="18-25" <?php if ($filter_age == "18-25")
                                echo "selected"; ?>>18-25 years
                            </option>
                            <option value="26-30" <?php if ($filter_age == "26-30")
                                echo "selected"; ?>>26-30 years
                            </option>
                            <option value="no-limit" <?php if ($filter_age == "no-limit")
                                echo "selected"; ?>>No Age Limit
                            </option>
                        </select>
                    </div>
                    <div class="md:w-1/2">
                        <label for="filter_qualification" class="block text-gray-700 mb-2">Filter by
                            Qualification:</label>
                        <select id="filter_qualification" name="filter_qualification"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="" <?php if ($filter_qualification == "")
                                echo "selected"; ?>>All Qualifications
                            </option>
                            <option value="Bachelor" <?php if ($filter_qualification == "Bachelor")
                                echo "selected"; ?>>
                                Bachelor's Degree</option>
                            <option value="Engineering" <?php if ($filter_qualification == "Engineering")
                                echo "selected"; ?>>Engineering</option>
                            <option value="12th" <?php if ($filter_qualification == "12th")
                                echo "selected"; ?>>12th Pass
                            </option>
                            <option value="10th" <?php if ($filter_qualification == "10th")
                                echo "selected"; ?>>10th Pass
                            </option>
                            <option value="Master" <?php if ($filter_qualification == "Master")
                                echo "selected"; ?>>
                                Master's Degree</option>
                        </select>
                    </div>
                </div>

                <div class="flex justify-center">
                    <button type="submit"
                        class="px-6 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Search Exams
                    </button>
                </div>
            </form>
        </div>

        <!-- Results Section -->
        <div class="mb-4">
            <?php if ($result && $result->num_rows > 0): ?>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Found <?php echo $result->num_rows; ?> exam(s)</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div
                            class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                            <div class="bg-blue-600 text-white px-4 py-3">
                                <h3 class="font-bold text-lg truncate"
                                    title="<?php echo htmlspecialchars($row["exam_name"]); ?>">
                                    <?php echo htmlspecialchars($row["exam_name"]); ?>
                                </h3>
                            </div>
                            <div class="p-4 space-y-3">
                                <div>
                                    <span class="font-semibold text-gray-700">Age Limit:</span>
                                    <span class="text-gray-600"><?php echo htmlspecialchars($row["age_limit"]); ?></span>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Minimum Percentage:</span>
                                    <span
                                        class="text-gray-600"><?php echo htmlspecialchars($row["minimum_percentage"]); ?></span>
                                </div>
                                <div>
                                    <span class="font-semibold text-gray-700">Qualification:</span>
                                    <p class="text-gray-600"><?php echo htmlspecialchars($row["academic_qualification"]); ?></p>
                                </div>
                                <div class="pt-2">
                                    <a href="<?php echo htmlspecialchars($row["official_website"]); ?>" target="_blank"
                                        class="inline-block px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                                        Official Website
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php elseif ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
                <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md">
                    <p>No exams found matching your search criteria. Please try different keywords or filters.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <footer class="bg-blue-800 text-white py-4 mt-8">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Indian Government Exams Search. All rights reserved.</p>
        </div>
    </footer>
</body>

</html>

<?php
// Close connection
$conn->close();
?>